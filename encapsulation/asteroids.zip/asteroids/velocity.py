class Velocity:
    def __init__(self, dx=0, dy=0):
        """
        Sets the self.dx and self.dy variables to 0 or passed in value.

        Return: none
        """
        self.dx = dx
        self.dy = dy
