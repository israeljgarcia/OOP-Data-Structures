class Point:
    def __init__(self, x=0, y=0):
        """
        Sets the self.x and self.y variables to 0 or passed in value.

        Return: none
        """
        self.x = x
        self.y = y
